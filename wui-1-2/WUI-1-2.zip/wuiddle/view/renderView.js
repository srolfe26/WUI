Fiddle.view.renderView = new Wui.Pane({
    height: '60%',
    width: '50%',
    title: 'Render',
    cls: 'rightFloat',
    border: false
});